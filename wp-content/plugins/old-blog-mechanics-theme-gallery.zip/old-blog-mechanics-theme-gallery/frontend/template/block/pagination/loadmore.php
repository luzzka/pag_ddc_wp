<div class="load_more col-xs-12 text-center"
     data-twoJG-page="<?php echo $page; ?>"
     data-twoJG-per_page="<?php echo $perPage; ?>"
     data-twoJG-pages="<?php echo $pages; ?>" >
	<a href="#" class="btn btn-default">
		<?php echo $buttonLoadMore; ?>
	</a>
</div>
