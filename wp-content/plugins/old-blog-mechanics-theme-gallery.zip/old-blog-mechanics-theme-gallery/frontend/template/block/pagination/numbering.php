<div class="numbering twoJGalleryCSSwrap"
     data-twoJG-page="<?php echo $page; ?>"
     data-twoJG-per_page="<?php echo $perPage; ?>"
     data-twoJG-pages="<?php echo $pages; ?>" >
</div>
