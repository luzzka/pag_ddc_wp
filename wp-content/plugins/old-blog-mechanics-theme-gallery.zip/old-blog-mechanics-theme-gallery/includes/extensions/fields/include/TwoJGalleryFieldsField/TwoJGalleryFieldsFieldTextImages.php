<?php

class TwoJGalleryFieldsFieldTextImages extends TwoJGalleryFieldsField{

}
