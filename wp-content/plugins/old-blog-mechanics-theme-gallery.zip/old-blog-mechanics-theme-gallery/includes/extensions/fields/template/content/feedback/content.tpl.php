<p id="twoj_gallery_fields_feedback_message" class="">
	Some ideas or suggestion for plugin functionality feel free to drop a line
</p>
<div id="field_feedback_form" class=" ui form">
	 <div class="ui large field">
	 	<label for="twoj_field_feedback_message">Message</label>
	    <textarea id="twoj_field_feedback_message" placeholder="Message"></textarea>
	</div>
	 <div class="field">
    	<label for="twoj_field_feedback_email">Email</label>
	    <input id="twoj_field_feedback_email" placeholder="Email" type="text">
	</div>
	<div align="center">
		<button id="twojGalleryFeedbackButton" class="ui button primary expanded ">Send</button>
	</div>

	
</div>

<div align="center">
	If you have support request please <a href="http://2joomla.net/products/index.php?option=com_sharedcrm&controller=ticket&task=show_form_ticket&Itemid=8" target="_blank">post ticket here</a>
</div>