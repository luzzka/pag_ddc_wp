<p class="offer">
	Only today you can get premium gallery version for free!
</p>
<div align="center">
	<a href="http://2joomla.net/products/index.php?option=com_sharedcrm&controller=ticket&task=show_form_ticket&Itemid=8&product=gallery&type=getFree" target="_blank" class="button success large button  offerButton">Contact Us</a>
</div>