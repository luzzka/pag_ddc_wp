<p id="twoj_gallery_fields_voting_message" class="offer">
	please vote for new feature which you wish to see implemented in our gallery
</p>

<div id="twoj_gallery_fields_voting_buttons" align="center">
	<button class="button success large button expanded twojGalleryVotingButton" data-vote="1">new grid layout</button>
	<button class="button success large button expanded twojGalleryVotingButton" data-vote="2">hover effect</button>
	<button class="button success large button expanded twojGalleryVotingButton" data-vote="3">description for lightbox</button>
</div>